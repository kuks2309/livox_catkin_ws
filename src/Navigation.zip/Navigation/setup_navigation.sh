#!/bin/bash

# HDL-Graph-SLAM + move_base 통합 테스트 스크립트

echo "=== HDL Navigation 시스템 설정 ==="

# 1. 필요한 패키지 설치
echo "1. 필요한 ROS 패키지 설치..."
sudo apt-get update
sudo apt-get install -y \
    ros-noetic-move-base \
    ros-noetic-pointcloud-to-laserscan \
    ros-noetic-teb-local-planner \
    ros-noetic-map-server \
    ros-noetic-amcl \
    ros-noetic-dwa-local-planner \
    ros-noetic-global-planner

# 2. workspace 빌드
echo "2. Navigation 패키지 빌드..."
cd /home/amap/2025_one_fifth_catkin_ws
catkin_make

# 3. 환경 설정
echo "3. 환경 설정..."
source devel/setup.bash

echo "=== 설정 완료 ==="
echo ""
echo "테스트 실행 방법:"
echo ""
echo "1. 차량 제어 시작:"
echo "   roslaunch m_car_encoder_serial henes_car_control_serial_odom.launch"
echo ""
echo "2. HDL Navigation 시작:"
echo "   roslaunch Navigation hdl_navigation.launch"
echo ""
echo "3. 목표점 설정:"
echo "   RViz에서 '2D Nav Goal' 버튼으로 목표점 설정"
echo ""
echo "토픽 확인:"
echo "   rostopic list | grep -E '(scan|map|cmd_vel|odom)'"
