# Navigation Package 사용법

## 개요
HDL-Graph-SLAM 기반 자율주행 네비게이션 시스템과 TEB waypoint 생성기

## 빠른 시작

### 1. 빌드
```bash
cd ~/2025_one_fifth_catkin_ws
catkin_make
source devel/setup.bash
```

### 2. 맵 서버 실행
```bash
rosrun map_server map_server /home/amap/2025_one_fifth_catkin_ws/map/5floor_lidar.yaml
```

### 3. 네비게이션 실행

```

#### TEB Local Planner 사용 (권장):
```bash
roslaunch navigation move_base_teb.launch
```


### 4. TEB Waypoint Generator 실행
```bash
# 1m 간격 (기본값)
roslaunch navigation teb_waypoint_generator.launch

```

### 5. RViz 시각화
```bash
rviz
```

#### RViz 필수 설정:
- **Fixed Frame**: `map`

#### 추가할 토픽들:

**1. 맵 표시:**
- Add → Map → Topic: `/map`

**2. TEB Waypoint (생성된 waypoint):**
- Add → Path → Topic: `/teb_waypoints` 
- Color: Green

**3. Waypoint 마커 (파란색 원형):**
- Add → MarkerArray → Topic: `/teb_waypoint_markers`

**4. TEB 로컬 경로:**
- Add → Path → Topic: `/move_base/TebLocalPlannerROS/local_plan`
- Color: Red

**5. 글로벌 경로:**
- Add → Path → Topic: `/move_base/GlobalPlanner/plan`
- Color: Blue

## 출력 토픽

### TEB Waypoint Generator:
- `/teb_waypoints` - nav_msgs/Path (1m 간격 waypoint 경로)  <- 추가 안해도 됨
- `/teb_waypoint_markers` - visualization_msgs/MarkerArray (시각화 마커)

### Move Base:
- `/move_base/GlobalPlanner/plan` - 전역 경로
- `/move_base/TebLocalPlannerROS/local_plan` - TEB 로컬 경로
- `/move_base/TebLocalPlannerROS/global_plan` - TEB 전역 경로

## 사용 방법

1. 모든 노드 실행
2. RViz에서 "2D Nav Goal" 클릭
3. 목표점 설정
4. TEB가 경로 생성하면 자동으로 waypoint 생성
5. 파란색 원형 마커로 waypoint 확인

## 파라미터

### TEB Waypoint Generator:
- `waypoint_spacing`: waypoint 간격 (기본: 1.0m)
- `input_topic`: 입력 경로 토픽 (기본: TEB local_plan)
- `output_topic`: 출력 waypoint 토픽
- `waypoint_frame`: waypoint 프레임 (기본: map)

## 문제 해결

### 빌드 오류:
```bash
catkin_make clean
catkin_make
```

### 토픽 확인:
```bash
rostopic list | grep teb
rostopic echo /teb_waypoints -n 1
```
