#include <ros/ros.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>
#include <visualization_msgs/MarkerArray.h>
#include <visualization_msgs/Marker.h>
#include <vector>
#include <cmath>

class TebWaypointGenerator
{
private:
    ros::NodeHandle nh_;
    ros::Subscriber path_sub_;
    ros::Publisher waypoint_pub_;
    ros::Publisher marker_pub_;
    
    // Parameters
    double waypoint_spacing_;
    std::string input_topic_;
    std::string output_topic_;
    std::string marker_topic_;
    std::string waypoint_frame_;
    
    nav_msgs::Path current_path_;
    bool path_received_;

public:
    TebWaypointGenerator() : path_received_(false)
    {
        // Load parameters
        nh_.param("waypoint_spacing", waypoint_spacing_, 1.0);
        nh_.param("input_topic", input_topic_, std::string("/move_base/TebLocalPlannerROS/local_plan"));
        nh_.param("output_topic", output_topic_, std::string("/teb_waypoints"));
        nh_.param("marker_topic", marker_topic_, std::string("/teb_waypoint_markers"));
        nh_.param("waypoint_frame", waypoint_frame_, std::string("map"));
        
        // Subscribers
        path_sub_ = nh_.subscribe(input_topic_, 1, &TebWaypointGenerator::pathCallback, this);
        
        // Publishers
        waypoint_pub_ = nh_.advertise<nav_msgs::Path>(output_topic_, 1);
        marker_pub_ = nh_.advertise<visualization_msgs::MarkerArray>(marker_topic_, 1);
        
        ROS_INFO("TEB Waypoint Generator initialized:");
        ROS_INFO("  - Waypoint spacing: %.2f m", waypoint_spacing_);
        ROS_INFO("  - Input topic: %s", input_topic_.c_str());
        ROS_INFO("  - Output topic: %s", output_topic_.c_str());
        ROS_INFO("  - Marker topic: %s", marker_topic_.c_str());
    }
    
    void pathCallback(const nav_msgs::Path::ConstPtr& msg)
    {
        if (msg->poses.empty()) {
            ROS_WARN("Received empty path");
            return;
        }
        
        current_path_ = *msg;
        path_received_ = true;
        
        ROS_DEBUG("Received path with %lu poses", msg->poses.size());
        
        // Generate waypoints from the received path
        generateWaypoints();
    }
    
    double calculateDistance(const geometry_msgs::PoseStamped& pose1, 
                           const geometry_msgs::PoseStamped& pose2)
    {
        double dx = pose2.pose.position.x - pose1.pose.position.x;
        double dy = pose2.pose.position.y - pose1.pose.position.y;
        double dz = pose2.pose.position.z - pose1.pose.position.z;
        return sqrt(dx*dx + dy*dy + dz*dz);
    }
    
    void calculateOrientation(geometry_msgs::PoseStamped& waypoint,
                            const geometry_msgs::PoseStamped& next_pose)
    {
        double dx = next_pose.pose.position.x - waypoint.pose.position.x;
        double dy = next_pose.pose.position.y - waypoint.pose.position.y;
        
        if (dx == 0 && dy == 0) {
            // Keep original orientation if no direction available
            return;
        }
        
        double yaw = atan2(dy, dx);
        
        // Convert yaw to quaternion
        waypoint.pose.orientation.x = 0.0;
        waypoint.pose.orientation.y = 0.0;
        waypoint.pose.orientation.z = sin(yaw / 2.0);
        waypoint.pose.orientation.w = cos(yaw / 2.0);
    }
    
    void generateWaypoints()
    {
        if (!path_received_ || current_path_.poses.empty()) {
            return;
        }
        
        std::vector<geometry_msgs::PoseStamped> waypoints;
        
        // Always add the first pose as starting waypoint
        waypoints.push_back(current_path_.poses[0]);
        
        double accumulated_distance = 0.0;
        size_t last_waypoint_index = 0;
        
        for (size_t i = 1; i < current_path_.poses.size(); i++) {
            double distance = calculateDistance(current_path_.poses[i-1], current_path_.poses[i]);
            accumulated_distance += distance;
            
            // Check if we've traveled enough distance for a new waypoint
            if (accumulated_distance >= waypoint_spacing_) {
                geometry_msgs::PoseStamped waypoint = current_path_.poses[i];
                waypoint.header.frame_id = waypoint_frame_;
                waypoint.header.stamp = ros::Time::now();
                
                // Calculate orientation based on direction to next pose
                if (i + 1 < current_path_.poses.size()) {
                    calculateOrientation(waypoint, current_path_.poses[i + 1]);
                } else if (waypoints.size() > 0) {
                    // For last waypoint, use direction from previous waypoint
                    calculateOrientation(waypoint, current_path_.poses[i]);
                }
                
                waypoints.push_back(waypoint);
                accumulated_distance = 0.0;
                last_waypoint_index = i;
            }
        }
        
        // Always add the last pose as final waypoint if it's not already added
        if (last_waypoint_index < current_path_.poses.size() - 1) {
            geometry_msgs::PoseStamped final_waypoint = current_path_.poses.back();
            final_waypoint.header.frame_id = waypoint_frame_;
            final_waypoint.header.stamp = ros::Time::now();
            waypoints.push_back(final_waypoint);
        }
        
        // Publish waypoints
        publishWaypoints(waypoints);
        
        ROS_INFO("Generated %lu waypoints from %lu path poses (spacing: %.2f m)", 
                 waypoints.size(), current_path_.poses.size(), waypoint_spacing_);
    }
    
    void publishWaypoints(const std::vector<geometry_msgs::PoseStamped>& waypoints)
    {
        // Publish as Path message
        nav_msgs::Path waypoint_path;
        waypoint_path.header.frame_id = waypoint_frame_;
        waypoint_path.header.stamp = ros::Time::now();
        waypoint_path.poses = waypoints;
        waypoint_pub_.publish(waypoint_path);
        
        // Publish visualization markers
        publishMarkers(waypoints);
    }
    
    void publishMarkers(const std::vector<geometry_msgs::PoseStamped>& waypoints)
    {
        visualization_msgs::MarkerArray marker_array;
        
        // Clear previous markers
        visualization_msgs::Marker clear_marker;
        clear_marker.header.frame_id = waypoint_frame_;
        clear_marker.header.stamp = ros::Time::now();
        clear_marker.ns = "waypoints";
        clear_marker.action = visualization_msgs::Marker::DELETEALL;
        marker_array.markers.push_back(clear_marker);
        
        clear_marker.ns = "waypoint_numbers";
        marker_array.markers.push_back(clear_marker);
        
        clear_marker.ns = "waypoint_arrows";
        marker_array.markers.push_back(clear_marker);
        
        // Create waypoint markers
        for (size_t i = 0; i < waypoints.size(); i++) {
            // Sphere marker for waypoint position
            visualization_msgs::Marker sphere_marker;
            sphere_marker.header.frame_id = waypoint_frame_;
            sphere_marker.header.stamp = ros::Time::now();
            sphere_marker.ns = "waypoints";
            sphere_marker.id = i;
            sphere_marker.type = visualization_msgs::Marker::CYLINDER;
            sphere_marker.action = visualization_msgs::Marker::ADD;
            
            sphere_marker.pose = waypoints[i].pose;
            sphere_marker.scale.x = 0.2;  // Diameter
            sphere_marker.scale.y = 0.2;  // Diameter
            sphere_marker.scale.z = 0.1;  // Height (thin cylinder = circle)
            
            // Blue color for all waypoints
            sphere_marker.color.r = 0.0;
            sphere_marker.color.g = 0.0;
            sphere_marker.color.b = 1.0;
            sphere_marker.color.a = 0.8;
            
            marker_array.markers.push_back(sphere_marker);
            
            // Text marker for waypoint number
            visualization_msgs::Marker text_marker;
            text_marker.header.frame_id = waypoint_frame_;
            text_marker.header.stamp = ros::Time::now();
            text_marker.ns = "waypoint_numbers";
            text_marker.id = i;
            text_marker.type = visualization_msgs::Marker::TEXT_VIEW_FACING;
            text_marker.action = visualization_msgs::Marker::ADD;
            
            text_marker.pose = waypoints[i].pose;
            text_marker.pose.position.z += 0.5;  // Offset text above waypoint
            text_marker.scale.z = 0.3;
            
            text_marker.color.r = 1.0;
            text_marker.color.g = 1.0;
            text_marker.color.b = 1.0;
            text_marker.color.a = 1.0;
            
            text_marker.text = std::to_string(i);
            
            marker_array.markers.push_back(text_marker);
            
            // Arrow marker for waypoint orientation
            visualization_msgs::Marker arrow_marker;
            arrow_marker.header.frame_id = waypoint_frame_;
            arrow_marker.header.stamp = ros::Time::now();
            arrow_marker.ns = "waypoint_arrows";
            arrow_marker.id = i;
            arrow_marker.type = visualization_msgs::Marker::ARROW;
            arrow_marker.action = visualization_msgs::Marker::ADD;
            
            arrow_marker.pose = waypoints[i].pose;
            arrow_marker.scale.x = 0.5;  // Length
            arrow_marker.scale.y = 0.1;  // Width
            arrow_marker.scale.z = 0.1;  // Height
            
            arrow_marker.color.r = 0.0;
            arrow_marker.color.g = 0.0;
            arrow_marker.color.b = 1.0;
            arrow_marker.color.a = 0.7;
            
            marker_array.markers.push_back(arrow_marker);
        }
        
        marker_pub_.publish(marker_array);
    }
};

int main(int argc, char** argv)
{
    ros::init(argc, argv, "teb_waypoint_generator");
    
    TebWaypointGenerator generator;
    
    ROS_INFO("TEB Waypoint Generator started. Waiting for TEB local plan...");
    
    ros::spin();
    
    return 0;
}